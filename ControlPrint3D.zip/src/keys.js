module.exports = {
    database: {
        host: 'localhost',
        user: 'root',
        password: 'anyelo2023',
        database: 'proyecto_titulo'
    }
};

